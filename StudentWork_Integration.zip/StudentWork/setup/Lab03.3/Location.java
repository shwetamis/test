package com.car.core;

import java.io.Serializable;

public class Location implements Serializable{
	
	private long id;
	private String owner;
	private String city;
	public Location(int id, String owner, String city) {
		this.id = id;
		this.city = city;
		this.owner = owner;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getOwner() {
		return owner;
	}
	public void setOwner(String owner) {
		this.owner = owner;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	@Override
	public String toString() {
		return "Location [id=" + id + ", owner=" + owner + ", city=" + city
				+ "]";
	}
	 
}
