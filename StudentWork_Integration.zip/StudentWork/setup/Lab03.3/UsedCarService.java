package com.car.core;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;
 @Component
public class UsedCarService {
	
	private static Map<Long,Location> locations;
	
	private static List<UsedCar> cars = new ArrayList<UsedCar>();
	
	static {
		 locations = new HashMap<Long,Location>();
		 locations.put(123L,new Location(123, "Spanking Good Cars, Preston Road", "Dallas"));
		 locations.put(456L,new Location(456, "Central Calico Cars, Main Street", "Fort Worth"));
		 locations.put(12345L,new Location(789, "McPasha Motors, Highway 121", "Dallas"));
		 locations.put(999L,new Location(999, "Default Motors, Coit Street", "Waco"));
	}
	
	public Location register(UsedCar car){
		System.out.println(car);
		long id = car.getId();
		cars.add(car);
		Location location = locations.get(999);
		if (locations.containsKey(id)){
		  location = locations.get(id);
		} else {
		location = locations.get(123);
		}
		System.out.println("Activator " + location + " " + Thread.currentThread().getName());
		return location;
	}

}
